import React from 'react'
import { motion } from 'framer-motion'

export default function Dashboard({ onEnterScorch }) {
  return (
    <div className="dashboard">
      <div className="dashboard-bg" />
      <div className="dashboard-center">
        <motion.h1 className="pick-world" initial={{ y: -20, opacity: 0 }} animate={{ y: 0, opacity: 1 }}>
          PICK A WORLD
        </motion.h1>

        <div className="world-cards">
          <motion.button
            className="world-card scorch"
            whileHover={{ y: -8, rotateX: 6, boxShadow: '0 20px 60px rgba(255,100,0,0.4)' }}
            whileTap={{ scale: 0.98 }}
            onClick={onEnterScorch}
          >
            <div className="card-overlay" />
            <div className="card-title">SCORCH ZONE</div>
            <div className="card-thermo hot">50°C</div>
            <div className="flame-edge" />
          </motion.button>

          <motion.div
            className="world-card blizzard disabled"
            whileHover={{ y: -3 }}
          >
            <div className="card-overlay" />
            <div className="card-title">BLIZZARD ZONE</div>
            <div className="card-thermo cold">-30°C</div>
            <div className="frost-edge" />
            <div className="locked">COMING SOON</div>
          </motion.div>
        </div>
      </div>

      <aside className="side-panel left">
        <h3>CHARACTER SELECT</h3>
        <div className="char-shelf">
          <div className="char holo rotate" />
          <div className="char holo" />
          <div className="char holo" />
        </div>
      </aside>

      <aside className="side-panel right">
        <h3>VIRTUAL EARTH</h3>
        <div className="earth-widget">
          <div className="satellite" />
          <div className="overlay-stats">
            <div>Temp +1.2°C</div>
            <div>CO₂ 420 ppm</div>
          </div>
        </div>
      </aside>
    </div>
  )
}
