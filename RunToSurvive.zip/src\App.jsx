import React, { useEffect, useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import Splash from './components/Splash.jsx'
import Dashboard from './components/Dashboard.jsx'
import ScorchZone from './components/ScorchZone.jsx'
import './styles.css'

export default function App() {
  const [screen, setScreen] = useState('splash') // splash | dashboard | scorch

  useEffect(() => {
    const t = setTimeout(() => setScreen('dashboard'), 2600)
    return () => clearTimeout(t)
  }, [])

  return (
    <div className="app-root">
      <AnimatePresence mode="wait">
        {screen === 'splash' && (
          <motion.div key="splash" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
            <Splash />
          </motion.div>
        )}

        {screen === 'dashboard' && (
          <motion.div key="dashboard" initial={{ opacity: 0, filter: 'blur(6px)' }} animate={{ opacity: 1, filter: 'blur(0px)' }} exit={{ opacity: 0 }}>
            <Dashboard onEnterScorch={() => setScreen('scorch')} />
          </motion.div>
        )}

        {screen === 'scorch' && (
          <motion.div key="scorch" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
            <ScorchZone onExit={() => setScreen('dashboard')} />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  )
}
