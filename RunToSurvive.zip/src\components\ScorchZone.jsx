import React, { useEffect, useMemo, useRef, useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import QuizModal from './quiz/QuizModal.jsx'
import { QUESTIONS } from '../data/questions.js'

// Constants
const LANES = [-1, 0, 1] // left, mid, right
const LANE_WIDTH = 140
const GROUND_Y = 420
const PLAYER_WIDTH = 60
const PLAYER_HEIGHT = 90
const GAME_SPEED_BASE = 6

// Spawning rules
const CACTUS_MIN_GAP = 320 // px between cacti groups
const CACTUS_GROUP_SIZE_RANGE = [1, 2] // 1-2 like Subway Surfers
const CHANCE_CARD_GAP = 900 // ensure not too frequent

function randBetween(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min
}

function nextCactusSpawnX(lastX) {
  return lastX + CACTUS_MIN_GAP + randBetween(0, 240)
}

function nextChanceCardSpawnX(lastX) {
  return lastX + CHANCE_CARD_GAP + randBetween(0, 400)
}

export default function ScorchZone({ onExit }) {
  const [score, setScore] = useState(0)
  const [health, setHealth] = useState(100)
  const [laneIndex, setLaneIndex] = useState(1) // start center
  const [isJumping, setIsJumping] = useState(false)
  const [yOffset, setYOffset] = useState(0)
  const [paused, setPaused] = useState(false)
  const [quiz, setQuiz] = useState({ open: false, q: null })
  const worldRef = useRef(null)
  const rafRef = useRef(0)
  const tRef = useRef(0)
  const playerRef = useRef({ vy: 0 })

  const [cacti, setCacti] = useState([]) // {x, lane}
  const [cards, setCards] = useState([]) // {x, lane}

  // Initialize obstacles
  useEffect(() => {
    let cx = 600
    const initial = []
    for (let i = 0; i < 4; i++) {
      const groupSize = randBetween(CACTUS_GROUP_SIZE_RANGE[0], CACTUS_GROUP_SIZE_RANGE[1])
      const groupLanes = [...LANES]
      for (let g = 0; g < groupSize; g++) {
        // pick a distinct lane within group
        const idx = randBetween(0, groupLanes.length - 1)
        const lane = groupLanes.splice(idx, 1)[0]
        initial.push({ x: cx + g * 60, lane })
      }
      cx = nextCactusSpawnX(cx)
    }
    setCacti(initial)

    let cardx = 900
    setCards([{ x: cardx, lane: 0 }])
  }, [])

  // Key controls: left/right change lanes; space to jump; P pause; Esc exit
  useEffect(() => {
    const onKey = e => {
      if (quiz.open) return
      if (e.key === 'ArrowLeft' || e.key === 'a') setLaneIndex(i => Math.max(0, i - 1))
      if (e.key === 'ArrowRight' || e.key === 'd') setLaneIndex(i => Math.min(2, i + 1))
      if (e.key === ' ' || e.key === 'Spacebar') {
        e.preventDefault()
        if (!isJumping) {
          setIsJumping(true)
          playerRef.current.vy = -14
        }
      }
      if (e.key === 'p') setPaused(p => !p)
      if (e.key === 'Escape') onExit?.()
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [isJumping, quiz.open, onExit])

  // Game loop
  useEffect(() => {
    const tick = () => {
      const dt = 16
      tRef.current += dt
      if (!paused && !quiz.open) {
        // world speed increases slightly with score
        const speed = GAME_SPEED_BASE + Math.min(8, Math.floor(score / 100))

        // Scroll obstacles
        setCacti(prev => prev
          .map(o => ({ ...o, x: o.x - speed }))
          .filter(o => o.x > -200)
        )
        setCards(prev => prev
          .map(o => ({ ...o, x: o.x - speed }))
          .filter(o => o.x > -200)
        )

        // Spawn new cacti if needed
        setCacti(prev => {
          let list = [...prev]
          const farthest = list.reduce((m, o) => Math.max(m, o.x), 0)
          if (farthest < 900) {
            let spawnX = nextCactusSpawnX(farthest || 600)
            const groupSize = randBetween(CACTUS_GROUP_SIZE_RANGE[0], CACTUS_GROUP_SIZE_RANGE[1])
            const lanesPool = [...LANES]
            for (let g = 0; g < groupSize; g++) {
              const pick = randBetween(0, lanesPool.length - 1)
              const lane = lanesPool.splice(pick, 1)[0]
              list.push({ x: spawnX + g * 70, lane })
            }
          }
          return list
        })

        // Spawn chance card if needed (ensure not clustered with cactus)
        setCards(prev => {
          let list = [...prev]
          const farthest = list.reduce((m, o) => Math.max(m, o.x), 0)
          if (farthest < 1200) {
            const spawnX = nextChanceCardSpawnX(Math.max(farthest, 900))
            const lane = LANES[randBetween(0, LANES.length - 1)]
            // make sure not within 200px of a cactus in same lane
            const conflict = cacti.some(c => c.lane === lane && Math.abs(c.x - spawnX) < 220)
            if (!conflict) list.push({ x: spawnX, lane })
          }
          return list
        })

        // Jump physics
        if (isJumping) {
          playerRef.current.vy += 0.9 // gravity
          setYOffset(y => {
            const ny = y + playerRef.current.vy
            if (ny >= 0) {
              setIsJumping(false)
              playerRef.current.vy = 0
              return 0
            }
            return ny
          })
        }

        // Collision checks (only if not jumping enough)
        const playerX = 220
        const playerLane = LANES[laneIndex]
        const playerTop = GROUND_Y - PLAYER_HEIGHT + yOffset
        const playerBottom = GROUND_Y + yOffset

        // Cactus collisions or jump scoring when passing
        cacti.forEach(c => {
          const cx = c.x
          if (c.lane === playerLane && Math.abs(cx - playerX) < 40) {
            // if feet are near ground -> hit
            if (playerBottom > GROUND_Y - 10) {
              setHealth(h => Math.max(0, h - 20))
            }
          }
          // award +5 when player safely passes cactus center while airborne or avoided
          if (cx < playerX - 45 && !c.scored) {
            c.scored = true
            setScore(s => s + 5)
          }
        })

        // Chance card trigger -> open quiz
        cards.forEach(card => {
          if (card.lane === playerLane && Math.abs(card.x - playerX) < 40 && !quiz.open) {
            const q = QUESTIONS[randBetween(0, QUESTIONS.length - 1)]
            setQuiz({ open: true, q })
          }
        })
      }
      rafRef.current = requestAnimationFrame(tick)
    }
    rafRef.current = requestAnimationFrame(tick)
    return () => cancelAnimationFrame(rafRef.current)
  }, [paused, quiz.open, isJumping, laneIndex, cacti, cards, score])

  const laneX = useMemo(() => 220 + LANES[laneIndex] * LANE_WIDTH, [laneIndex])

  // Quiz handlers
  const handleAnswer = correct => {
    if (correct) {
      setScore(s => s + 10)
    } else {
      setHealth(h => Math.max(0, h - 15))
    }
    setQuiz({ open: false, q: null })
  }

  // Game over
  useEffect(() => {
    if (health <= 0) {
      setPaused(true)
      // small delay then show modal restart
    }
  }, [health])

  return (
    <div className="scorch-zone">
      <div className="skybox" />
      <div className="sun" />
      <div className="hud">
        <div className="meter">
          <div className="earth-icon" />
          <div className="bar"><div className="fill" style={{ width: `${health}%` }} /></div>
        </div>
        <div className="score">Score {score}</div>
        <div className="hint">Arrows/A-D to switch lanes • Space to jump • P pause • Esc back</div>
      </div>

      <div className="track">
        <div className="lane" />
        <div className="lane" />
        <div className="lane" />
      </div>

      <div className="ground" />

      <div className="player" style={{ transform: `translate(${laneX}px, ${yOffset}px)` }}>
        <div className="runner-body">
          <div className="visor" />
          <div className="trail heat" />
        </div>
      </div>

      {/* Cacti */}
      {cacti.map((c, idx) => (
        <div
          key={`c${idx}`}
          className="cactus"
          style={{ transform: `translate(${c.x}px, 0)` , left: 220 + c.lane * LANE_WIDTH }}
        >
          <div className="arm left" />
          <div className="arm right" />
        </div>
      ))}

      {/* Chance Cards */}
      {cards.map((card, idx) => (
        <div
          key={`card${idx}`}
          className="chance-card"
          style={{ transform: `translate(${card.x}px, 0)`, left: 220 + card.lane * LANE_WIDTH }}
        >
          <div className="qm">?</div>
        </div>
      ))}

      <AnimatePresence>
        {quiz.open && (
          <QuizModal question={quiz.q} onAnswer={handleAnswer} />
        )}
      </AnimatePresence>

      {health <= 0 && (
        <div className="game-over">
          <div className="title">CLIMATE CATASTROPHE</div>
          <button onClick={() => { setHealth(100); setScore(0); setPaused(false) }}>Restart</button>
          <button onClick={onExit}>Exit</button>
        </div>
      )}
    </div>
  )
}
